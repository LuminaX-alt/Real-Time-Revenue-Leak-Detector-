import { Hero } from "@/components/hero"
import { UserInputDemo } from "@/components/user-input-demo"
import { LiveDemo } from "@/components/live-demo"
import { WhatItDoes } from "@/components/what-it-does"
import { BuiltWith } from "@/components/built-with"
import { Journey } from "@/components/journey"
import { WhatsNext } from "@/components/whats-next"
import { Footer } from "@/components/footer"
import { Header } from "@/components/header"

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <Hero />
        <UserInputDemo />
        <LiveDemo />
        <WhatItDoes />
        <BuiltWith />
        <Journey />
        <WhatsNext />
      </main>
      <Footer />
    </div>
  )
}
