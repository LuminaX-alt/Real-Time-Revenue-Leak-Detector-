"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Brain, Zap, Shield, TrendingUp } from "lucide-react"

interface AnomalyDetectorProps {
  isRunning: boolean
  onAnomaly: (type: string, message: string, amount: number) => void
}

interface DetectionRule {
  name: string
  description: string
  confidence: number
  status: "active" | "triggered" | "normal"
  icon: React.ElementType
}

export function AnomalyDetector({ isRunning, onAnomaly }: AnomalyDetectorProps) {
  const [rules, setRules] = useState<DetectionRule[]>([
    {
      name: "Pricing Rule Validation",
      description: "Validates pricing calculations against defined rules",
      confidence: 95,
      status: "active",
      icon: Shield,
    },
    {
      name: "Usage Pattern Analysis",
      description: "Detects unusual usage billing patterns",
      confidence: 88,
      status: "normal",
      icon: TrendingUp,
    },
    {
      name: "Transaction Anomaly Detection",
      description: "ML-based detection of transaction irregularities",
      confidence: 92,
      status: "active",
      icon: Brain,
    },
    {
      name: "Real-time Threshold Monitoring",
      description: "Monitors for values exceeding normal thresholds",
      confidence: 97,
      status: "normal",
      icon: Zap,
    },
  ])

  useEffect(() => {
    if (!isRunning) return

    const interval = setInterval(() => {
      setRules((prevRules) =>
        prevRules.map((rule) => {
          const shouldTrigger = Math.random() < 0.1 // 10% chance to trigger
          const newConfidence = Math.max(85, Math.min(99, rule.confidence + (Math.random() - 0.5) * 10))

          if (shouldTrigger && rule.status !== "triggered") {
            // Trigger anomaly detection
            const anomalyTypes = [
              "PRICING_RULE_VIOLATION",
              "USAGE_ANOMALY",
              "TRANSACTION_IRREGULARITY",
              "THRESHOLD_EXCEEDED",
            ]
            const messages = [
              `${rule.name} detected pricing discrepancy`,
              `${rule.name} found unusual billing pattern`,
              `${rule.name} identified transaction anomaly`,
              `${rule.name} threshold violation detected`,
            ]

            const randomIndex = Math.floor(Math.random() * anomalyTypes.length)
            onAnomaly(anomalyTypes[randomIndex], messages[randomIndex], Math.random() * 200 + 50)

            return { ...rule, status: "triggered" as const, confidence: newConfidence }
          } else if (rule.status === "triggered" && Math.random() < 0.3) {
            // Reset triggered rules
            return { ...rule, status: "normal" as const, confidence: newConfidence }
          }

          return { ...rule, confidence: newConfidence }
        }),
      )
    }, 3000)

    return () => clearInterval(interval)
  }, [isRunning, onAnomaly])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200"
      case "triggered":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
      case "normal":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200"
    }
  }

  return (
    <Card>
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-lg sm:text-xl">
          <Brain className="h-5 w-5" />
          Anomaly Detection Engine
        </CardTitle>
        <CardDescription className="text-sm">ML-powered real-time revenue leak detection rules</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4 sm:space-y-6">
          {rules.map((rule, index) => (
            <div key={index} className="space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div className="flex items-start sm:items-center space-x-3 flex-1 min-w-0">
                  <rule.icon className="h-5 w-5 text-muted-foreground flex-shrink-0 mt-0.5 sm:mt-0" />
                  <div className="min-w-0 flex-1">
                    <h4 className="font-medium text-sm sm:text-base">{rule.name}</h4>
                    <p className="text-xs sm:text-sm text-muted-foreground">{rule.description}</p>
                  </div>
                </div>
                <Badge className={`${getStatusColor(rule.status)} text-xs self-start sm:self-center`}>
                  {rule.status}
                </Badge>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-xs sm:text-sm">
                  <span>Confidence Level</span>
                  <span>{rule.confidence.toFixed(1)}%</span>
                </div>
                <Progress value={rule.confidence} className="h-2" />
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 sm:mt-6 p-3 sm:p-4 bg-muted/50 rounded-lg">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 text-sm">
            <span className="font-medium">System Status</span>
            <div className="flex items-center space-x-2">
              <div className={`h-2 w-2 rounded-full ${isRunning ? "bg-green-500" : "bg-gray-400"}`} />
              <span className="text-xs sm:text-sm">{isRunning ? "Active Monitoring" : "Paused"}</span>
            </div>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            {isRunning
              ? "All detection rules are actively monitoring for revenue leaks"
              : "Start the demo to begin real-time monitoring"}
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
