import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ImageIcon } from "lucide-react"

export function Architecture() {
  return (
    <section className="py-16 sm:py-24 lg:py-32">
      <div className="container px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight">Architecture</h2>
          <p className="mt-3 sm:mt-4 text-base sm:text-lg text-muted-foreground">
            Serverless, scalable, and secure architecture designed for high availability
          </p>
        </div>
        <div className="mx-auto mt-12 sm:mt-16 max-w-4xl">
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="text-lg sm:text-xl">System Architecture Diagram</CardTitle>
              <CardDescription className="text-sm sm:text-base">
                Event-driven serverless architecture with real-time processing capabilities
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex aspect-video items-center justify-center rounded-lg border-2 border-dashed border-muted-foreground/25 bg-muted/50">
                <div className="text-center p-4">
                  <ImageIcon className="mx-auto h-8 w-8 sm:h-12 sm:w-12 text-muted-foreground/50" />
                  <p className="mt-2 text-xs sm:text-sm text-muted-foreground">
                    Architecture diagram will be embedded here
                  </p>
                  <p className="text-xs text-muted-foreground/75">(Placeholder for architecture image)</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
