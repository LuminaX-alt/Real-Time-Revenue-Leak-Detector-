import { Card, CardContent } from "@/components/ui/card"
import { Cloud, Database, Activity, Workflow, Code, Brain, Bell, CreditCard } from "lucide-react"

const technologies = [
  { name: "AWS Lambda", icon: Cloud, description: "Serverless compute" },
  { name: "EventBridge", icon: Workflow, description: "Event routing" },
  { name: "DynamoDB", icon: Database, description: "NoSQL database" },
  { name: "CloudWatch", icon: Activity, description: "Monitoring & logs" },
  { name: "Step Functions", icon: Workflow, description: "Workflow orchestration" },
  { name: "Python", icon: Code, description: "Backend language" },
  { name: "Scikit-learn", icon: Brain, description: "Machine learning" },
  { name: "SNS", icon: Bell, description: "Notifications" },
  { name: "Stripe/Razorpay", icon: CreditCard, description: "Payment processing" },
]

export function BuiltWith() {
  return (
    <section className="py-16 sm:py-24 lg:py-32 bg-muted/50">
      <div className="container px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight">Built With</h2>
          <p className="mt-3 sm:mt-4 text-base sm:text-lg text-muted-foreground">
            Powered by cutting-edge AWS services and modern technologies
          </p>
        </div>
        <div className="mx-auto mt-12 sm:mt-16 grid max-w-6xl grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {technologies.map((tech, index) => (
            <Card key={index} className="group hover:shadow-md transition-shadow h-full">
              <CardContent className="flex flex-col items-center p-4 sm:p-6 text-center h-full">
                <div className="flex h-10 w-10 sm:h-12 sm:w-12 items-center justify-center rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 group-hover:scale-110 transition-transform">
                  <tech.icon className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
                </div>
                <h3 className="mt-3 sm:mt-4 font-semibold text-sm sm:text-base">{tech.name}</h3>
                <p className="mt-1 text-xs sm:text-sm text-muted-foreground">{tech.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
