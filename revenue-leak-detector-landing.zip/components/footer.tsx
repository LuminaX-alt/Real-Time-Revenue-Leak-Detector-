import { Button } from "@/components/ui/button"
import { Github, Mail, Phone, Linkedin } from "lucide-react"

export function Footer() {
  return (
    <footer className="border-t bg-muted/50">
      <div className="container py-8 sm:py-12 px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-blue-600 to-purple-600 flex-shrink-0" />
            <span className="font-bold text-sm sm:text-base text-center sm:text-left">
              Real-Time Revenue Leak Detector
            </span>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-4">
            <Button variant="ghost" size="sm" asChild>
              <a
                href="https://github.com/LuminaX-alt/Real-Time-Revenue-Leak-Detector-"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Github className="h-4 w-4 mr-2" />
                <span className="hidden sm:inline">GitHub</span>
              </a>
            </Button>
            <Button variant="ghost" size="sm" asChild>
              <a href="tel:+919123144609">
                <Phone className="h-4 w-4 mr-2" />
                <span className="hidden sm:inline">+91 9123144609</span>
              </a>
            </Button>
            <Button variant="ghost" size="sm" asChild>
              <a href="mailto:12devsharma11a@gmail.com">
                <Mail className="h-4 w-4 mr-2" />
                <span className="hidden sm:inline">Email</span>
              </a>
            </Button>
            <Button variant="ghost" size="sm" asChild>
              <a href="https://www.linkedin.com/in/dev-sharma-7a263a2a0" target="_blank" rel="noopener noreferrer">
                <Linkedin className="h-4 w-4 mr-2" />
                <span className="hidden sm:inline">LinkedIn</span>
              </a>
            </Button>
          </div>
        </div>
        <div className="mt-6 sm:mt-8 border-t pt-6 sm:pt-8 text-center text-xs sm:text-sm text-muted-foreground">
          <p>Built for AWS Lambda Hackathon • Deployed on Vercel</p>
          <p className="mt-2 text-xs">
            Contact:{" "}
            <a href="tel:+919123144609" className="hover:underline">
              +91 9123144609
            </a>{" "}
            |
            <a href="mailto:12devsharma11a@gmail.com" className="hover:underline ml-1">
              12devsharma11a@gmail.com
            </a>
          </p>
        </div>
      </div>
    </footer>
  )
}
