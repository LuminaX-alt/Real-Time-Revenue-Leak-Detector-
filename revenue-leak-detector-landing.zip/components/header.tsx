import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/theme-toggle"
import { Github } from "lucide-react"
import Image from "next/image"

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center justify-between px-4 sm:px-6 lg:px-8">
        <div className="flex items-center space-x-3">
          <Image src="/logo.png" alt="LuminaX-Alt Logo" width={32} height={32} className="rounded-md" />
          <span className="font-bold text-sm sm:text-base truncate">Revenue Leak Detector</span>
        </div>
        <div className="flex items-center space-x-3">
          <Button variant="ghost" size="sm" asChild className="hidden sm:flex">
            <a
              href="https://github.com/LuminaX-alt/Real-Time-Revenue-Leak-Detector-"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Github className="h-4 w-4" />
              GitHub
            </a>
          </Button>
          <Button variant="ghost" size="sm" asChild className="sm:hidden">
            <a
              href="https://github.com/LuminaX-alt/Real-Time-Revenue-Leak-Detector-"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Github className="h-4 w-4" />
            </a>
          </Button>
          <ThemeToggle />
        </div>
      </div>
    </header>
  )
}
