import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Lightbulb, Wrench, GraduationCap } from "lucide-react"

const journeyItems = [
  {
    icon: Lightbulb,
    title: "Inspiration",
    description:
      "Witnessing how small billing discrepancies can compound into significant revenue losses for SaaS companies. The need for real-time detection became clear when manual audits were catching issues weeks too late.",
  },
  {
    icon: Wrench,
    title: "Challenges",
    description:
      "Building a system that could process high-volume transaction streams without false positives. Balancing detection sensitivity with performance while keeping costs low in a serverless environment.",
  },
  {
    icon: GraduationCap,
    title: "What We Learned",
    description:
      "The power of event-driven architecture for real-time processing. How machine learning can be effectively deployed in serverless environments, and the importance of designing for observability from day one.",
  },
]

export function Journey() {
  return (
    <section className="py-16 sm:py-24 lg:py-32 bg-muted/50">
      <div className="container px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight">Our Hackathon Journey</h2>
          <p className="mt-3 sm:mt-4 text-base sm:text-lg text-muted-foreground">
            From inspiration to implementation - the story behind the project
          </p>
        </div>
        <div className="mx-auto mt-12 sm:mt-16 grid max-w-5xl grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
          {journeyItems.map((item, index) => (
            <Card key={index} className="h-full">
              <CardHeader className="pb-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br from-blue-500 to-purple-600">
                  <item.icon className="h-6 w-6 text-white" />
                </div>
                <CardTitle className="text-lg sm:text-xl">{item.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-sm sm:text-base leading-relaxed">{item.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
