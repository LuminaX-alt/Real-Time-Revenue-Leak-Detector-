"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertTriangle, DollarSign, TrendingUp, Zap, Play, Pause, RotateCcw } from "lucide-react"
import { RevenueChart } from "./revenue-chart"
import { TransactionStream } from "./transaction-stream"
import { AnomalyDetector } from "./anomaly-detector"

export function LiveDemo() {
  const [isRunning, setIsRunning] = useState(true) // Auto-start the demo
  const [totalRevenue, setTotalRevenue] = useState(125847.32)
  const [leaksDetected, setLeaksDetected] = useState(0)
  const [leaksPrevented, setLeaksPrevented] = useState(0)
  const [alerts, setAlerts] = useState<
    Array<{ id: string; type: string; message: string; amount: number; timestamp: Date }>
  >([])

  // Auto-increment revenue when running
  useEffect(() => {
    if (!isRunning) return

    const interval = setInterval(() => {
      setTotalRevenue((prev) => prev + Math.random() * 50 + 10)
    }, 3000)

    return () => clearInterval(interval)
  }, [isRunning])

  const toggleDemo = () => {
    setIsRunning(!isRunning)
  }

  const resetDemo = () => {
    setIsRunning(false)
    setLeaksDetected(0)
    setLeaksPrevented(0)
    setAlerts([])
    setTotalRevenue(125847.32)
  }

  const addAlert = (type: string, message: string, amount: number) => {
    const newAlert = {
      id: Math.random().toString(36).substr(2, 9),
      type,
      message,
      amount,
      timestamp: new Date(),
    }
    setAlerts((prev) => [newAlert, ...prev.slice(0, 4)])
    setLeaksDetected((prev) => prev + 1)
    setLeaksPrevented((prev) => prev + amount)
  }

  return (
    <section
      data-demo-section
      className="py-12 sm:py-16 lg:py-24 bg-gradient-to-br from-blue-50/50 via-white to-purple-50/50 dark:from-blue-950/10 dark:via-background dark:to-purple-950/10"
    >
      <div className="container px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center mb-8 sm:mb-12 lg:mb-16">
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight">Live Revenue Protection Demo</h2>
          <p className="mt-3 sm:mt-4 text-base sm:text-lg text-muted-foreground">
            Watch real-time anomaly detection in action - preventing revenue leaks as they happen
          </p>
          <div className="mt-6 sm:mt-8 flex flex-col sm:flex-row justify-center gap-3 sm:gap-4">
            <Button
              onClick={toggleDemo}
              className={`w-full sm:w-auto ${isRunning ? "bg-red-600 hover:bg-red-700" : "bg-green-600 hover:bg-green-700"}`}
            >
              {isRunning ? <Pause className="mr-2 h-4 w-4" /> : <Play className="mr-2 h-4 w-4" />}
              {isRunning ? "Pause Demo" : "Start Demo"}
            </Button>
            <Button onClick={resetDemo} variant="outline" className="w-full sm:w-auto">
              <RotateCcw className="mr-2 h-4 w-4" />
              Reset
            </Button>
          </div>
        </div>

        {/* Real-time Metrics */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-6 sm:mb-8">
          <Card className="p-4 sm:p-6">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 p-0">
              <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent className="p-0 pt-2">
              <div className="text-xl sm:text-2xl font-bold">${totalRevenue.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground flex items-center mt-1">
                <TrendingUp className="inline h-3 w-3 mr-1" />
                +12.5% from last month
              </p>
            </CardContent>
          </Card>

          <Card className="p-4 sm:p-6">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 p-0">
              <CardTitle className="text-sm font-medium">Leaks Detected</CardTitle>
              <AlertTriangle className="h-4 w-4 text-red-500" />
            </CardHeader>
            <CardContent className="p-0 pt-2">
              <div className="text-xl sm:text-2xl font-bold text-red-600">{leaksDetected}</div>
              <p className="text-xs text-muted-foreground">Real-time detection active</p>
            </CardContent>
          </Card>

          <Card className="p-4 sm:p-6">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 p-0">
              <CardTitle className="text-sm font-medium">Revenue Saved</CardTitle>
              <Zap className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent className="p-0 pt-2">
              <div className="text-xl sm:text-2xl font-bold text-green-600">${leaksPrevented.toFixed(2)}</div>
              <p className="text-xs text-muted-foreground">Prevented losses</p>
            </CardContent>
          </Card>

          <Card className="p-4 sm:p-6">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 p-0">
              <CardTitle className="text-sm font-medium">System Health</CardTitle>
              <div className={`h-2 w-2 rounded-full ${isRunning ? "bg-green-500" : "bg-gray-400"}`} />
            </CardHeader>
            <CardContent className="p-0 pt-2">
              <div className="text-xl sm:text-2xl font-bold">{isRunning ? "99.9%" : "Paused"}</div>
              <p className="text-xs text-muted-foreground">{isRunning ? "All systems operational" : "Demo paused"}</p>
            </CardContent>
          </Card>
        </div>

        {/* Live Charts and Streams */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8 mb-6 sm:mb-8">
          <RevenueChart isRunning={isRunning} />
          <TransactionStream isRunning={isRunning} onAnomaly={addAlert} />
        </div>

        {/* Anomaly Detection Engine */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
          <div className="lg:col-span-2">
            <AnomalyDetector isRunning={isRunning} onAnomaly={addAlert} />
          </div>

          {/* Live Alerts */}
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-2 text-lg">
                <AlertTriangle className="h-5 w-5 text-red-500" />
                Live Alerts
              </CardTitle>
              <CardDescription>Real-time revenue leak notifications</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 sm:space-y-4">
              {alerts.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-6 sm:py-8">
                  {isRunning ? "Monitoring for anomalies..." : "Start demo to see alerts"}
                </p>
              ) : (
                alerts.map((alert) => (
                  <Alert key={alert.id} className="border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-950/20">
                    <AlertTriangle className="h-4 w-4 text-red-600" />
                    <AlertDescription>
                      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-2">
                        <div className="flex-1">
                          <p className="font-medium text-red-800 dark:text-red-200 text-sm">{alert.message}</p>
                          <p className="text-xs text-red-600 dark:text-red-400 mt-1">
                            ${alert.amount.toFixed(2)} • {alert.timestamp.toLocaleTimeString()}
                          </p>
                        </div>
                        <Badge variant="destructive" className="text-xs self-start">
                          {alert.type}
                        </Badge>
                      </div>
                    </AlertDescription>
                  </Alert>
                ))
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
