"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

interface RevenueChartProps {
  isRunning: boolean
}

export function RevenueChart({ isRunning }: RevenueChartProps) {
  const [data, setData] = useState([
    { time: "00:00", revenue: 1250, expected: 1250, anomaly: false },
    { time: "00:05", revenue: 1280, expected: 1275, anomaly: false },
    { time: "00:10", revenue: 1290, expected: 1300, anomaly: false },
    { time: "00:15", revenue: 1310, expected: 1325, anomaly: false },
    { time: "00:20", revenue: 1340, expected: 1350, anomaly: false },
  ])

  useEffect(() => {
    if (!isRunning) return

    const interval = setInterval(() => {
      setData((prevData) => {
        const lastPoint = prevData[prevData.length - 1]
        const newTime = new Date(Date.now())
          .toLocaleTimeString("en-US", {
            hour12: false,
            minute: "2-digit",
            second: "2-digit",
          })
          .slice(0, 5)

        const expectedRevenue = lastPoint.expected + Math.random() * 50 + 20
        const actualRevenue = expectedRevenue + (Math.random() - 0.5) * 100
        const isAnomaly = Math.abs(actualRevenue - expectedRevenue) > 30

        const newPoint = {
          time: newTime,
          revenue: Math.round(actualRevenue),
          expected: Math.round(expectedRevenue),
          anomaly: isAnomaly,
        }

        return [...prevData.slice(-19), newPoint]
      })
    }, 2000)

    return () => clearInterval(interval)
  }, [isRunning])

  return (
    <Card>
      <CardHeader className="pb-4">
        <CardTitle className="text-lg sm:text-xl">Revenue Tracking</CardTitle>
        <CardDescription className="text-sm">Real-time vs expected revenue with anomaly detection</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[250px] sm:h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data} margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
              <XAxis dataKey="time" tick={{ fontSize: 12 }} interval="preserveStartEnd" />
              <YAxis tick={{ fontSize: 12 }} width={60} />
              <Tooltip
                formatter={(value, name) => [`$${value}`, name === "revenue" ? "Actual Revenue" : "Expected Revenue"]}
                contentStyle={{
                  backgroundColor: "hsl(var(--background))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "6px",
                }}
              />
              <Line
                type="monotone"
                dataKey="expected"
                stroke="#8884d8"
                strokeDasharray="5 5"
                name="expected"
                strokeWidth={2}
              />
              <Line
                type="monotone"
                dataKey="revenue"
                stroke="#82ca9d"
                strokeWidth={2}
                name="revenue"
                dot={(props) => {
                  const { cx, cy, payload } = props
                  return payload.anomaly ? (
                    <circle cx={cx} cy={cy} r={4} fill="#ef4444" stroke="#dc2626" strokeWidth={2} />
                  ) : null
                }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
