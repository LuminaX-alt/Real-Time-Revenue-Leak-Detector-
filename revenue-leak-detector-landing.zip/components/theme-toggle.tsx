"use client"

import { useEffect, useState } from "react"
import { Moon, Sun } from "lucide-react"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"

export function ThemeToggle() {
  const [mounted, setMounted] = useState(false)
  const { theme, setTheme } = useTheme()

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <div className="flex items-center space-x-2">
        <Button variant="ghost" size="sm" className="text-xs">
          <Sun className="h-4 w-4 mr-1" />
          Light
        </Button>
        <Button variant="ghost" size="sm" className="text-xs">
          <Moon className="h-4 w-4 mr-1" />
          Dark
        </Button>
      </div>
    )
  }

  return (
    <div className="flex items-center space-x-2">
      <Button
        variant={theme === "light" ? "default" : "ghost"}
        size="sm"
        onClick={() => setTheme("light")}
        className="text-xs"
      >
        <Sun className="h-4 w-4 mr-1" />
        Light
      </Button>
      <Button
        variant={theme === "dark" ? "default" : "ghost"}
        size="sm"
        onClick={() => setTheme("dark")}
        className="text-xs"
      >
        <Moon className="h-4 w-4 mr-1" />
        Dark
      </Button>
    </div>
  )
}
