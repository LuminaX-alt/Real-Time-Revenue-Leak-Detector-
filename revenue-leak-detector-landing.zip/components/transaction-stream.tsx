"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { CheckCircle, XCircle, AlertTriangle } from "lucide-react"

interface Transaction {
  id: string
  customer: string
  amount: number
  expected: number
  status: "success" | "failed" | "anomaly"
  timestamp: Date
  type: string
}

interface TransactionStreamProps {
  isRunning: boolean
  onAnomaly: (type: string, message: string, amount: number) => void
}

const customers = ["Acme Corp", "TechStart Inc", "Global Solutions", "DataFlow Ltd", "CloudSync Pro", "DevTools Co"]
const transactionTypes = ["Subscription", "Usage Fee", "Setup Fee", "Overage", "Premium Feature"]

export function TransactionStream({ isRunning, onAnomaly }: TransactionStreamProps) {
  const [transactions, setTransactions] = useState<Transaction[]>([])

  useEffect(() => {
    if (!isRunning) return

    const interval = setInterval(() => {
      const customer = customers[Math.floor(Math.random() * customers.length)]
      const type = transactionTypes[Math.floor(Math.random() * transactionTypes.length)]
      const expectedAmount = Math.random() * 500 + 50
      const actualAmount = expectedAmount + (Math.random() - 0.5) * 100

      let status: "success" | "failed" | "anomaly" = "success"

      // Simulate different scenarios
      const scenario = Math.random()
      if (scenario < 0.05) {
        // 5% failed transactions
        status = "failed"
      } else if (Math.abs(actualAmount - expectedAmount) > 25) {
        // Billing mismatch
        status = "anomaly"
        onAnomaly(
          "BILLING_MISMATCH",
          `Billing mismatch detected for ${customer}`,
          Math.abs(actualAmount - expectedAmount),
        )
      }

      const newTransaction: Transaction = {
        id: Math.random().toString(36).substr(2, 9),
        customer,
        amount: actualAmount,
        expected: expectedAmount,
        status,
        timestamp: new Date(),
        type,
      }

      setTransactions((prev) => [newTransaction, ...prev.slice(0, 19)])
    }, 1500)

    return () => clearInterval(interval)
  }, [isRunning, onAnomaly])

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "success":
        return <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
      case "failed":
        return <XCircle className="h-4 w-4 text-red-500 flex-shrink-0" />
      case "anomaly":
        return <AlertTriangle className="h-4 w-4 text-yellow-500 flex-shrink-0" />
      default:
        return null
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "success":
        return (
          <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200 text-xs">Success</Badge>
        )
      case "failed":
        return (
          <Badge variant="destructive" className="text-xs">
            Failed
          </Badge>
        )
      case "anomaly":
        return (
          <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200 text-xs">
            Anomaly
          </Badge>
        )
      default:
        return null
    }
  }

  return (
    <Card>
      <CardHeader className="pb-4">
        <CardTitle className="text-lg sm:text-xl">Live Transaction Stream</CardTitle>
        <CardDescription className="text-sm">Real-time transaction monitoring with anomaly detection</CardDescription>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[250px] sm:h-[300px]">
          {transactions.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-6 sm:py-8">
              {isRunning ? "Processing transactions..." : "Start demo to see live transactions"}
            </p>
          ) : (
            <div className="space-y-3">
              {transactions.map((transaction) => (
                <div key={transaction.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3 flex-1 min-w-0">
                    {getStatusIcon(transaction.status)}
                    <div className="min-w-0 flex-1">
                      <p className="font-medium text-sm truncate">{transaction.customer}</p>
                      <p className="text-xs text-muted-foreground truncate">
                        {transaction.type} • {transaction.timestamp.toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0 ml-2">
                    <div className="flex items-center space-x-2 justify-end">
                      <span className="font-medium text-sm">${transaction.amount.toFixed(2)}</span>
                      {getStatusBadge(transaction.status)}
                    </div>
                    {transaction.status === "anomaly" && (
                      <p className="text-xs text-muted-foreground">Expected: ${transaction.expected.toFixed(2)}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
