"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertTriangle, CheckCircle, Calculator, TrendingUp, DollarSign, Zap } from "lucide-react"

interface AnalysisResult {
  isAnomaly: boolean
  confidence: number
  expectedRange: { min: number; max: number }
  deviation: number
  riskLevel: "low" | "medium" | "high"
  recommendation: string
  expectedAmount: number
  potentialLoss: number
}

export function UserInputDemo() {
  const [customerName, setCustomerName] = useState("")
  const [billedAmount, setBilledAmount] = useState("")
  const [usageHours, setUsageHours] = useState("")
  const [planType, setPlanType] = useState("")
  const [result, setResult] = useState<AnalysisResult | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)

  const analyzeRevenueLeak = () => {
    if (!customerName || !billedAmount || !usageHours || !planType) {
      return
    }

    setIsAnalyzing(true)

    // Simulate analysis delay for realistic feel
    setTimeout(() => {
      const billed = Number.parseFloat(billedAmount)
      const hours = Number.parseFloat(usageHours)

      // Calculate expected amount based on plan type
      const planRates = {
        basic: 10,
        premium: 25,
        enterprise: 50,
      }

      const rate = planRates[planType as keyof typeof planRates] || 10
      const expectedAmount = hours * rate
      const deviation = Math.abs(billed - expectedAmount)
      const deviationPercent = (deviation / expectedAmount) * 100

      // Determine if it's an anomaly (15% threshold)
      const isAnomaly = deviationPercent > 15

      // Calculate confidence based on deviation
      const confidence = Math.min(95, Math.max(60, 100 - deviationPercent))

      // Determine risk level
      let riskLevel: "low" | "medium" | "high" = "low"
      if (deviationPercent > 30) riskLevel = "high"
      else if (deviationPercent > 15) riskLevel = "medium"

      // Calculate potential loss
      const potentialLoss = billed < expectedAmount ? expectedAmount - billed : 0

      // Generate recommendation
      let recommendation = "Billing appears normal and within expected range."
      if (isAnomaly) {
        if (billed > expectedAmount) {
          recommendation = `Potential overcharge detected! Customer may be paying $${deviation.toFixed(2)} more than expected. Review pricing rules for ${planType} plan.`
        } else {
          recommendation = `Revenue leak detected! You're losing $${deviation.toFixed(2)} per billing cycle. Immediate action recommended.`
        }
      }

      const analysisResult: AnalysisResult = {
        isAnomaly,
        confidence,
        expectedRange: {
          min: expectedAmount * 0.85,
          max: expectedAmount * 1.15,
        },
        deviation,
        riskLevel,
        recommendation,
        expectedAmount,
        potentialLoss,
      }

      setResult(analysisResult)
      setIsAnalyzing(false)
    }, 2500) // Realistic analysis time
  }

  const resetForm = () => {
    setCustomerName("")
    setBilledAmount("")
    setUsageHours("")
    setPlanType("")
    setResult(null)
  }

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case "high":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
      case "medium":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
      case "low":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200"
    }
  }

  return (
    <section className="py-16 sm:py-24 lg:py-32 bg-gradient-to-br from-blue-50/50 via-white to-purple-50/50 dark:from-blue-950/10 dark:via-background dark:to-purple-950/10">
      <div className="container px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight">
            Test Your Billing Data
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              {" "}
              Live Now
            </span>
          </h2>
          <p className="mt-4 sm:mt-6 text-lg sm:text-xl text-muted-foreground">
            Enter real billing information and watch our AI detect revenue leaks instantly
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 max-w-7xl mx-auto">
          {/* Input Form */}
          <Card className="shadow-lg">
            <CardHeader className="pb-6">
              <CardTitle className="flex items-center gap-3 text-xl">
                <Calculator className="h-6 w-6 text-blue-600" />
                Revenue Analysis Input
              </CardTitle>
              <CardDescription className="text-base">
                Enter customer billing data to detect potential revenue leaks
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <Label htmlFor="customer" className="text-sm font-medium">
                  Customer Name
                </Label>
                <Input
                  id="customer"
                  placeholder="e.g., Acme Corporation"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="h-11"
                />
              </div>

              <div className="space-y-3">
                <Label htmlFor="amount" className="text-sm font-medium">
                  Actual Billed Amount ($)
                </Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  placeholder="e.g., 1250.00"
                  value={billedAmount}
                  onChange={(e) => setBilledAmount(e.target.value)}
                  className="h-11"
                />
              </div>

              <div className="space-y-3">
                <Label htmlFor="usage" className="text-sm font-medium">
                  Usage Hours
                </Label>
                <Input
                  id="usage"
                  type="number"
                  placeholder="e.g., 120"
                  value={usageHours}
                  onChange={(e) => setUsageHours(e.target.value)}
                  className="h-11"
                />
              </div>

              <div className="space-y-3">
                <Label htmlFor="plan" className="text-sm font-medium">
                  Subscription Plan
                </Label>
                <select
                  id="plan"
                  className="w-full h-11 px-3 py-2 border border-input bg-background rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                  value={planType}
                  onChange={(e) => setPlanType(e.target.value)}
                >
                  <option value="">Select subscription plan</option>
                  <option value="basic">Basic Plan ($10/hour)</option>
                  <option value="premium">Premium Plan ($25/hour)</option>
                  <option value="enterprise">Enterprise Plan ($50/hour)</option>
                </select>
              </div>

              <div className="flex gap-3 pt-6">
                <Button
                  onClick={analyzeRevenueLeak}
                  disabled={!customerName || !billedAmount || !usageHours || !planType || isAnalyzing}
                  className="flex-1 h-11 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                >
                  {isAnalyzing ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Zap className="mr-2 h-4 w-4" />
                      Detect Revenue Leaks
                    </>
                  )}
                </Button>
                <Button onClick={resetForm} variant="outline" className="h-11">
                  Reset
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Results Panel */}
          <Card className="shadow-lg">
            <CardHeader className="pb-6">
              <CardTitle className="flex items-center gap-3 text-xl">
                <TrendingUp className="h-6 w-6 text-green-600" />
                Analysis Results
              </CardTitle>
              <CardDescription className="text-base">
                AI-powered revenue leak detection and recommendations
              </CardDescription>
            </CardHeader>
            <CardContent>
              {!result && !isAnalyzing && (
                <div className="text-center py-16 text-muted-foreground">
                  <Calculator className="h-16 w-16 mx-auto mb-6 opacity-30" />
                  <h3 className="text-lg font-medium mb-2">Ready to Analyze</h3>
                  <p className="text-sm">Fill in the billing data and click "Detect Revenue Leaks" to see results</p>
                </div>
              )}

              {isAnalyzing && (
                <div className="text-center py-16">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-6"></div>
                  <h3 className="text-lg font-medium mb-2">Analyzing Billing Data</h3>
                  <p className="text-sm text-muted-foreground mb-2">Running ML algorithms...</p>
                  <p className="text-xs text-muted-foreground">Checking for anomalies and patterns...</p>
                </div>
              )}

              {result && (
                <div className="space-y-6">
                  {/* Main Status Alert */}
                  <Alert
                    className={
                      result.isAnomaly
                        ? "border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-950/20"
                        : "border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-950/20"
                    }
                  >
                    {result.isAnomaly ? (
                      <AlertTriangle className="h-5 w-5 text-red-600" />
                    ) : (
                      <CheckCircle className="h-5 w-5 text-green-600" />
                    )}
                    <AlertDescription>
                      <div className="font-semibold text-base mb-2">
                        {result.isAnomaly ? "🚨 Revenue Leak Detected!" : "✅ Billing Looks Good"}
                      </div>
                      <p className="text-sm leading-relaxed">{result.recommendation}</p>
                    </AlertDescription>
                  </Alert>

                  {/* Key Metrics */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950/20 dark:to-blue-900/20 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">{result.confidence.toFixed(1)}%</div>
                      <div className="text-sm text-muted-foreground">Confidence</div>
                    </div>
                    <div className="text-center p-4 bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-950/20 dark:to-purple-900/20 rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">${result.deviation.toFixed(2)}</div>
                      <div className="text-sm text-muted-foreground">Deviation</div>
                    </div>
                  </div>

                  {/* Financial Impact */}
                  {result.potentialLoss > 0 && (
                    <div className="p-4 bg-red-50 dark:bg-red-950/20 rounded-lg border border-red-200 dark:border-red-800">
                      <div className="flex items-center gap-2 mb-2">
                        <DollarSign className="h-5 w-5 text-red-600" />
                        <span className="font-semibold text-red-800 dark:text-red-200">Revenue Loss Impact</span>
                      </div>
                      <div className="text-2xl font-bold text-red-600 mb-1">${result.potentialLoss.toFixed(2)}</div>
                      <div className="text-sm text-red-700 dark:text-red-300">Lost per billing cycle</div>
                    </div>
                  )}

                  {/* Expected vs Actual */}
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="font-medium">Expected Amount:</span>
                      <span className="text-green-600 font-semibold">${result.expectedAmount.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="font-medium">Actual Billed:</span>
                      <span className="font-semibold">${billedAmount}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="font-medium">Risk Level:</span>
                      <Badge className={getRiskColor(result.riskLevel)}>{result.riskLevel.toUpperCase()} RISK</Badge>
                    </div>
                  </div>

                  {/* Expected Range */}
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <div className="text-sm font-medium mb-2">Normal Billing Range</div>
                    <div className="text-sm text-muted-foreground">
                      ${result.expectedRange.min.toFixed(2)} - ${result.expectedRange.max.toFixed(2)}
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">Based on {planType} plan usage patterns</div>
                  </div>

                  {/* Customer Summary */}
                  <div className="pt-4 border-t">
                    <h4 className="font-semibold mb-3">Analysis Summary</h4>
                    <div className="text-sm space-y-2 text-muted-foreground">
                      <div className="flex justify-between">
                        <span>Customer:</span>
                        <span className="font-medium text-foreground">{customerName}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Plan:</span>
                        <span className="font-medium text-foreground">
                          {planType.charAt(0).toUpperCase() + planType.slice(1)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Usage:</span>
                        <span className="font-medium text-foreground">{usageHours} hours</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
