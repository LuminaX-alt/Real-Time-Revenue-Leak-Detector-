import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertTriangle, DollarSign, Shield, Zap, TrendingUp } from "lucide-react"

const features = [
  {
    icon: Zap,
    title: "Real-time Anomaly Detection",
    description: "Instantly identify unusual billing patterns and revenue discrepancies as they occur.",
  },
  {
    icon: AlertTriangle,
    title: "Billing Mismatch Alerts",
    description: "Get immediate notifications when billing amounts don't match expected calculations.",
  },
  {
    icon: Shield,
    title: "Pricing Rule Validation",
    description: "Ensure pricing rules are correctly applied across all customer transactions.",
  },
  {
    icon: DollarSign,
    title: "Failed Transaction Monitoring",
    description: "Track and analyze failed payments to recover lost revenue opportunities.",
  },
  {
    icon: TrendingUp,
    title: "Usage-based Billing Integrity",
    description: "Verify usage metrics align with billing calculations for subscription services.",
  },
]

export function WhatItDoes() {
  return (
    <section className="py-16 sm:py-24 lg:py-32">
      <div className="container px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight">What It Does</h2>
          <p className="mt-3 sm:mt-4 text-base sm:text-lg text-muted-foreground">
            Comprehensive revenue protection through intelligent monitoring and analysis
          </p>
        </div>
        <div className="mx-auto mt-12 sm:mt-16 grid max-w-5xl grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="relative overflow-hidden h-full">
              <CardHeader className="pb-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br from-blue-500 to-purple-600">
                  <feature.icon className="h-6 w-6 text-white" />
                </div>
                <CardTitle className="text-lg sm:text-xl">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-sm sm:text-base leading-relaxed">
                  {feature.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
