import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle } from "lucide-react"

const roadmapItems = [
  "Interactive dashboard UI with real-time visualizations",
  "Native Stripe and Razorpay integration for seamless setup",
  "Advanced ML models with custom anomaly thresholds",
  "Auto-healing system to automatically fix detected issues",
  "Open-source release with community contributions",
  "Multi-tenant SaaS platform with team collaboration",
  "API integrations with popular billing platforms",
  "Predictive analytics for revenue forecasting",
]

export function WhatsNext() {
  return (
    <section className="py-16 sm:py-24 lg:py-32">
      <div className="container px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight">What's Next</h2>
          <p className="mt-3 sm:mt-4 text-base sm:text-lg text-muted-foreground">
            Our roadmap for expanding the platform and adding new capabilities
          </p>
        </div>
        <div className="mx-auto mt-12 sm:mt-16 max-w-3xl">
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="text-lg sm:text-xl">Upcoming Features</CardTitle>
              <CardDescription className="text-sm sm:text-base">
                Planned enhancements and new capabilities coming soon
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3 sm:gap-4 sm:grid-cols-2">
                {roadmapItems.map((item, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <CheckCircle className="mt-0.5 h-4 w-4 sm:h-5 sm:w-5 text-green-500 flex-shrink-0" />
                    <span className="text-xs sm:text-sm leading-relaxed">{item}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
